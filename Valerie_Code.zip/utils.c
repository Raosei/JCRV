int IsAreaClicked(float area_center_x, float area_center_y, float area_width, float area_height, float click_x, float click_y)
{
	float minx = area_center_x - (area_width / 2);
	float maxx = area_center_x + (area_width / 2);
	float miny = area_center_y - (area_height / 2);
	float maxy = area_center_y + (area_height / 2);


	if (maxx >= click_x && minx <= click_x && maxy >= click_y && miny <= click_y)
	{
		return 1;
	}
	else {
		return 0;
	}
}