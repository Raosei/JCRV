#include "cprocessing.h"
#include "utils.h"
#include "mainmenu.h"
#include "testlvl.h"
//wrote comments :D just add in the code under EDIT HERE 

CP_Font Font;

void selection_Init(void) {
	Font = CP_Font_Load("Assets/BoldsPixels.ttf");
	CP_Font_Set(Font);
	CP_Settings_TextSize(52.f);
}

void selection_Update(void) {
	static int timer_on = 1;
	CP_Graphics_ClearBackground(CP_Color_Create(150, 150, 150, 255));

	CP_Settings_StrokeWeight(8.0f);
	CP_Settings_Fill(CP_Color_Create(255.0, 127.0, 127.0, 255));
	CP_Graphics_DrawRect(800.0f, 490.0f, 400.0f, 130.0f);//bottom

	CP_Settings_Fill(CP_Color_Create(255.0, 255.0, 220.0, 255));
	CP_Graphics_DrawRect(800.0f, 330.0f, 400.0f, 130.0f);//middle 

	CP_Settings_Fill(CP_Color_Create(127.0, 255.0, 127.0, 255));
	CP_Graphics_DrawRect(800.0f, 170.0f, 400.0f, 130.0f);//top

	CP_Graphics_DrawRect(800.0f, 650.0f, 300.0f, 110.0f);// timer select

	CP_Settings_Fill(CP_Color_Create(255.0, 127.0, 127.0, 255));
	CP_Graphics_DrawRect(185, 780, 190, 120);//back
	CP_Graphics_DrawRect(185, 780, 190, 120);

	CP_Settings_StrokeWeight(3.0f);

	//text
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Settings_TextAlignment(CP_TEXT_ALIGN_H_CENTER, CP_TEXT_ALIGN_V_MIDDLE);
	CP_Font_DrawText("Back", (float)CP_System_GetWindowWidth() / 8.5, (float)CP_System_GetWindowHeight() / 1.156);
	CP_Font_DrawText("Easy", (float)CP_System_GetWindowWidth() / 2, (float)CP_System_GetWindowHeight() / 5.2);
	CP_Font_DrawText("Medium", (float)CP_System_GetWindowWidth() /2, (float)CP_System_GetWindowHeight() / 2.8);
	CP_Font_DrawText("Hard", (float)CP_System_GetWindowWidth() /2, (float)CP_System_GetWindowHeight() / 1.86);

	float click_x = CP_Input_GetMouseX();
	float click_y = CP_Input_GetMouseY();
	//back
	if( IsAreaClicked(185.0f, 780.0f, 190.0f, 120.0f, click_x, click_y) && CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT)) {
		CP_Engine_SetNextGameState(Main_Menu_Init, Main_Menu_Update, Main_Menu_Exit);
		CP_Engine_Run(0);
	}
	//easy level select(EDIT HERE)
	if (IsAreaClicked(800.0f, 170.0f, 400.0f, 130.0f, click_x, click_y) && CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT)) {
		CP_Engine_SetNextGameState(testlvl_Init,testlvl_Update,testlvl_Exit);
		CP_Engine_Run(0);
	}
	//medium level select(EDIT HERE)
	if (IsAreaClicked(800.0f, 330.0f, 400.0f, 130.0f, click_x, click_y) && CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT)) {
		//CP_Engine_SetNextGameState();
		//CP_Engine_Run(0);
	}
	//hard level select(EDIT HERE)
	if (IsAreaClicked(800.0f, 490.0f, 400.0f, 130.0f, click_x, click_y) && CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT)) {
		//CP_Engine_SetNextGameState();
		//CP_Engine_Run(0);
	}

	//timer off
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT)&&IsAreaClicked(800.0f, 650.0f, 300.0f, 110.0f, click_x, click_y)&&timer_on) {
		timer_on=0;
	}
	else if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT) && IsAreaClicked(800.0f, 650.0f, 300.0f, 110.0f, click_x, click_y) && timer_on == 0) {
		timer_on = 1;
	}
	if (timer_on==0) {
		CP_Font_DrawText("Timer : Off", (float)CP_System_GetWindowWidth() / 2, (float)CP_System_GetWindowHeight() / 1.4);
		// timer off code :D (EDIT HERE)
	}
	else if (timer_on) {
		CP_Font_DrawText("Timer : On", (float)CP_System_GetWindowWidth() / 2, (float)CP_System_GetWindowHeight() / 1.4);
		//timer on code :D (EDIT HERE)
	}
}

void selection_Exit(void) {
	CP_Font_Free(Font);
}